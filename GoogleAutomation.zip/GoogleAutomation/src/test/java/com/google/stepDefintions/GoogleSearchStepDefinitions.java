package com.google.stepDefintions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import junit.framework.Assert;

public class GoogleSearchStepDefinitions {
	public static WebDriver driver;
	
	@Given("^user is on google page$")
	public void user_is_on_google_page() throws Throwable {
	   
System.setProperty("webdriver.chrome.driver","c:\\chromedriver.exe");
		
		ChromeOptions options =new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		driver=new ChromeDriver(options);
		driver.get("https://www.google.com/");
		driver.manage().window().maximize();
	}

	@Then("^user enter text for search$")
	public void user_enter_text_for_search() throws Throwable {
		driver.findElement(By.name("q")).sendKeys("Hello");
	}

	@Then("^user submit the search$")
public void user_submit_the_search()
	{
		driver.findElement(By.name("btnK")).submit();
	}

	@Then("^validate title is Hello- Google search$")
public void validate_title_is_Hello_Google_search() {

		String s=driver.getTitle();
		Assert.assertEquals("Hello - Google Search", s);
		
	}

	@Then("^close the browser$")
public void close_the_browser() throws Throwable {
        driver.quit();
	}

}
