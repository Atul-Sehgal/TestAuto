package com.google.runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(

		features="src\\test\\java\\com\\google\\feature\\GoogleSearch.feature",//the path of the feature files

		glue="com\\google\\stepDefintions",//the path of the step definition files
		format= {"pretty","html:test-output", "json:json_output/PPM_DataManager_CreateDataExtract_CNS.json", "junit:junit_xml/cucumber.xml", "com.cucumber.listener.ExtentCucumberFormatter:target/cucumber-reports/CrtDE_CNS.html"}, //to generate different types of reporting
	    //tags = {"@CreateDataExtractUNET, @CreateDataExtractCosmos"}, //@CreateDataExtract, @CreateDataExtractCosmos, @CreateModelBase , @ProviderSearch, "~@DeleteUCRTGroup"
        dryRun=false,// To check if mapping is proper between Step Definition and Feature file.
    	monochrome=true,//displays console output in proper readable format.
		strict=false//Fails the run if any step definitions is missing or not defined in step definition file. 
		)

public class TestRunner {

}
