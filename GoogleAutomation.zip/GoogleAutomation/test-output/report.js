$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/test/java/com/google/feature/GoogleSearch.feature");
formatter.feature({
  "line": 1,
  "name": "Google Search",
  "description": "",
  "id": "google-search",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 3,
  "name": "Google search feature with anonymous user.",
  "description": "",
  "id": "google-search;google-search-feature-with-anonymous-user.",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "user is on google page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "user enter text for search",
  "keyword": "Then "
});
formatter.step({
  "line": 7,
  "name": "user submit the search",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "validate title is Hello- Google search",
  "keyword": "Then "
});
formatter.step({
  "line": 9,
  "name": "close the browser",
  "keyword": "Then "
});
formatter.match({
  "location": "GoogleSearchStepDefinitions.user_is_on_google_page()"
});
formatter.result({
  "duration": 7504197743,
  "status": "passed"
});
formatter.match({
  "location": "GoogleSearchStepDefinitions.user_enter_text_for_search()"
});
formatter.result({
  "duration": 154050707,
  "status": "passed"
});
formatter.match({
  "location": "GoogleSearchStepDefinitions.user_submit_the_search()"
});
formatter.result({
  "duration": 2037887264,
  "status": "passed"
});
formatter.match({
  "location": "GoogleSearchStepDefinitions.validate_title_is_Hello_Google_search()"
});
formatter.result({
  "duration": 11098802,
  "status": "passed"
});
formatter.match({
  "location": "GoogleSearchStepDefinitions.close_the_browser()"
});
formatter.result({
  "duration": 1144685558,
  "status": "passed"
});
});