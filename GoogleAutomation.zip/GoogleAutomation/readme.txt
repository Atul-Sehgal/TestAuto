

1. TestRunner class- entry point- cucumber class has the definition for main method which controlling the entire workflow.
2. Feature file text file
3. step definitions
4. for executing go to test runner->run as junit
5. test report will be available after refreshing the project and under test output folder->index.html. also in json format, the defintion and config is mentioned in testrunner file.